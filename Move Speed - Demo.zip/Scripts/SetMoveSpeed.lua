game:Log("Modifying LuaDemoMove.moveSpeed...")

if demo ~= nil then
    game:Log("Original moveSpeed: " .. tostring(demo.moveSpeed))
    demo.moveSpeed = demo.moveSpeed * 2
    game:Log("New moveSpeed: " .. tostring(demo.moveSpeed))
else
    game:LogError("LuaDemoMove instance not found in Lua environment.")
end