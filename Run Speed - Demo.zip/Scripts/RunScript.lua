game:Log("Setting up sprint boost...")

if demo == nil then
    game:LogError("LuaDemoMove instance not found")
    return
end

-- Save original speed
local baseSpeed = demo.moveSpeed

-- Coroutine-like loop using update
function update()
    if game:IsKeyHeld("LeftShift") then
        demo.moveSpeed = baseSpeed * 2
    else
        demo.moveSpeed = baseSpeed
    end
end

-- Register the update loop
if game.RegisterUpdate ~= nil then
    game:RegisterUpdate(update)
else
    game:LogError("Update registration not available. Cannot apply sprint logic.")
end