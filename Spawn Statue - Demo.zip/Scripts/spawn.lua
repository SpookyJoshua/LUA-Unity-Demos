game:Log("Running spawn script")

-- Check available tags
local tags = game:GetModTags("StatueSpawnDemo")
if tags == nil then
    game:LogError("No tags returned!")
    return
end

for i = 1, #tags do
    game:Log("Available tag: " .. tags[i])
end

game:Log("Spawning scaled statue...")

-- Parameters: modId, tag, x, y, z, rx, ry, rz, sx, sy, sz
game:SpawnModelAt("StatueSpawnDemo", "statue", 0, 0, 0, 0, 180, 0, 0.03, 0.03, 0.03)